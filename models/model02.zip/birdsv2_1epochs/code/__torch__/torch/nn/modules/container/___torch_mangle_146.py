class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  __annotations__["0"] = __torch__.torchvision.ops.misc.Conv2dNormActivation
  __annotations__["1"] = __torch__.torch.nn.modules.container.___torch_mangle_16.Sequential
  __annotations__["2"] = __torch__.torch.nn.modules.container.___torch_mangle_42.Sequential
  __annotations__["3"] = __torch__.torch.nn.modules.container.___torch_mangle_62.Sequential
  __annotations__["4"] = __torch__.torch.nn.modules.container.___torch_mangle_82.Sequential
  __annotations__["5"] = __torch__.torch.nn.modules.container.___torch_mangle_102.Sequential
  __annotations__["6"] = __torch__.torch.nn.modules.container.___torch_mangle_122.Sequential
  __annotations__["7"] = __torch__.torch.nn.modules.container.___torch_mangle_142.Sequential
  __annotations__["8"] = __torch__.torchvision.ops.misc.___torch_mangle_145.Conv2dNormActivation
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_146.Sequential,
    input: Tensor) -> Tensor:
    _0 = getattr(self, "0")
    _1 = getattr(self, "1")
    _2 = getattr(self, "2")
    _3 = getattr(self, "3")
    _4 = getattr(self, "4")
    _5 = getattr(self, "5")
    _6 = getattr(self, "6")
    _7 = getattr(self, "7")
    _8 = getattr(self, "8")
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    input3 = (_3).forward(input2, )
    input4 = (_4).forward(input3, )
    input5 = (_5).forward(input4, )
    input6 = (_6).forward(input5, )
    input7 = (_7).forward(input6, )
    return (_8).forward(input7, )
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_146.Sequential) -> int:
    return 9
