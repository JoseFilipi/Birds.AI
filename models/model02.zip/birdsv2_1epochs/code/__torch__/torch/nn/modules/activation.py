class SiLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  inplace : Final[bool] = True
  def forward(self: __torch__.torch.nn.modules.activation.SiLU,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.silu(input, True, )
    return _0
class Sigmoid(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.Sigmoid,
    input: Tensor) -> Tensor:
    return torch.sigmoid(input)
