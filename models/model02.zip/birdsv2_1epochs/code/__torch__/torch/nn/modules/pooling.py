class AdaptiveAvgPool2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  output_size : Final[int] = 1
  def forward(self: __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.adaptive_avg_pool2d
    return _0(input, [1, 1], )
