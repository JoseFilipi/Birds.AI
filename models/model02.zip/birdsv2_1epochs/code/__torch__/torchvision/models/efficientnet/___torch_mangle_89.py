class MBConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  use_res_connect : bool
  out_channels : int
  block : __torch__.torch.nn.modules.container.___torch_mangle_88.Sequential
  stochastic_depth : __torch__.torchvision.ops.stochastic_depth.StochasticDepth
  def forward(self: __torch__.torchvision.models.efficientnet.___torch_mangle_89.MBConv,
    input: Tensor) -> Tensor:
    block = self.block
    result = (block).forward(input, )
    use_res_connect = self.use_res_connect
    if use_res_connect:
      stochastic_depth = self.stochastic_depth
      result1 = (stochastic_depth).forward(result, )
      result0 = torch.add_(result1, input)
    else:
      result0 = result
    return result0
