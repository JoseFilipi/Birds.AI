class EfficientNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  features : __torch__.torch.nn.modules.container.___torch_mangle_146.Sequential
  avgpool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  classifier : __torch__.torch.nn.modules.container.___torch_mangle_149.Sequential
  def forward(self: __torch__.torchvision.models.efficientnet.EfficientNet,
    x: Tensor) -> Tensor:
    return (self)._forward_impl(x, )
  def _forward_impl(self: __torch__.torchvision.models.efficientnet.EfficientNet,
    x: Tensor) -> Tensor:
    features = self.features
    x0 = (features).forward(x, )
    avgpool = self.avgpool
    x1 = (avgpool).forward(x0, )
    x2 = torch.flatten(x1, 1)
    classifier = self.classifier
    return (classifier).forward(x2, )
class MBConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  use_res_connect : bool
  out_channels : int
  block : __torch__.torch.nn.modules.container.Sequential
  stochastic_depth : __torch__.torchvision.ops.stochastic_depth.StochasticDepth
  def forward(self: __torch__.torchvision.models.efficientnet.MBConv,
    input: Tensor) -> Tensor:
    block = self.block
    result = (block).forward(input, )
    use_res_connect = self.use_res_connect
    if use_res_connect:
      stochastic_depth = self.stochastic_depth
      result1 = (stochastic_depth).forward(result, )
      result0 = torch.add_(result1, input)
    else:
      result0 = result
    return result0
