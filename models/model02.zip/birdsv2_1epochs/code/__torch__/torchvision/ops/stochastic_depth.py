class StochasticDepth(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  p : float
  mode : str
  def forward(self: __torch__.torchvision.ops.stochastic_depth.StochasticDepth,
    input: Tensor) -> Tensor:
    _0 = __torch__.torchvision.ops.stochastic_depth.stochastic_depth
    p = self.p
    mode = self.mode
    training = self.training
    return _0(input, p, mode, training, )
def stochastic_depth(input: Tensor,
    p: float,
    mode: str,
    training: bool=True) -> Tensor:
  _1 = "drop probability has to be between 0 and 1, but got {}"
  _2 = "mode has to be either \'batch\' or \'row\', but got {}"
  if torch.lt(p, 0.):
    _3 = True
  else:
    _3 = torch.gt(p, 1.)
  if _3:
    ops.prim.RaiseException(torch.format(_1, p), "builtins.ValueError")
  else:
    pass
  _4 = torch.__contains__(["batch", "row"], mode)
  if torch.__not__(_4):
    ops.prim.RaiseException(torch.format(_2, mode), "builtins.ValueError")
  else:
    pass
  if torch.__not__(training):
    _5 = True
  else:
    _5 = torch.eq(p, 0.)
  if _5:
    _6 = input
  else:
    survival_rate = torch.sub(1., p)
    if torch.eq(mode, "row"):
      _7 = [(torch.size(input))[0]]
      _8 = torch.mul([1], torch.sub(torch.dim(input), 1))
      size = torch.add(_7, _8)
    else:
      size = torch.mul([1], torch.dim(input))
    noise = torch.empty(size, dtype=ops.prim.dtype(input), layout=None, device=ops.prim.device(input))
    noise0 = torch.bernoulli_(noise, survival_rate)
    if torch.gt(survival_rate, 0.):
      _9 = torch.div_(noise0, survival_rate)
    else:
      pass
    _6 = torch.mul(input, noise0)
  return _6
