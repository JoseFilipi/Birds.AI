class Conv2dNormActivation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  out_channels : int
  __annotations__["0"] = __torch__.torch.nn.modules.conv.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  __annotations__["2"] = __torch__.torch.nn.modules.activation.SiLU
  def forward(self: __torch__.torchvision.ops.misc.Conv2dNormActivation,
    input: Tensor) -> Tensor:
    _0 = getattr(self, "0")
    _1 = getattr(self, "1")
    _2 = getattr(self, "2")
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    return (_2).forward(input1, )
  def __len__(self: __torch__.torchvision.ops.misc.Conv2dNormActivation) -> int:
    return 3
class SqueezeExcitation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  avgpool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  fc1 : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  fc2 : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  activation : __torch__.torch.nn.modules.activation.SiLU
  scale_activation : __torch__.torch.nn.modules.activation.Sigmoid
  def forward(self: __torch__.torchvision.ops.misc.SqueezeExcitation,
    input: Tensor) -> Tensor:
    scale = (self)._scale(input, )
    return torch.mul(scale, input)
  def _scale(self: __torch__.torchvision.ops.misc.SqueezeExcitation,
    input: Tensor) -> Tensor:
    avgpool = self.avgpool
    scale = (avgpool).forward(input, )
    fc1 = self.fc1
    scale0 = (fc1).forward(scale, )
    activation = self.activation
    scale1 = (activation).forward(scale0, )
    fc2 = self.fc2
    scale2 = (fc2).forward(scale1, )
    scale_activation = self.scale_activation
    _0 = (scale_activation).forward(scale2, )
    return _0
