class SqueezeExcitation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  avgpool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  fc1 : __torch__.torch.nn.modules.conv.___torch_mangle_135.Conv2d
  fc2 : __torch__.torch.nn.modules.conv.___torch_mangle_136.Conv2d
  activation : __torch__.torch.nn.modules.activation.SiLU
  scale_activation : __torch__.torch.nn.modules.activation.Sigmoid
  def forward(self: __torch__.torchvision.ops.misc.___torch_mangle_137.SqueezeExcitation,
    input: Tensor) -> Tensor:
    scale = (self)._scale(input, )
    return torch.mul(scale, input)
  def _scale(self: __torch__.torchvision.ops.misc.___torch_mangle_137.SqueezeExcitation,
    input: Tensor) -> Tensor:
    avgpool = self.avgpool
    scale = (avgpool).forward(input, )
    fc1 = self.fc1
    scale0 = (fc1).forward(scale, )
    activation = self.activation
    scale1 = (activation).forward(scale0, )
    fc2 = self.fc2
    scale2 = (fc2).forward(scale1, )
    scale_activation = self.scale_activation
    _0 = (scale_activation).forward(scale2, )
    return _0
