class Conv2dNormActivation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  out_channels : int
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_58.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_46.BatchNorm2d
  def forward(self: __torch__.torchvision.ops.misc.___torch_mangle_59.Conv2dNormActivation,
    input: Tensor) -> Tensor:
    _0 = getattr(self, "0")
    _1 = getattr(self, "1")
    input0 = (_0).forward(input, )
    return (_1).forward(input0, )
  def __len__(self: __torch__.torchvision.ops.misc.___torch_mangle_59.Conv2dNormActivation) -> int:
    return 2
